# INF1339-week01
Demo repository for INF1339 assignment 2
